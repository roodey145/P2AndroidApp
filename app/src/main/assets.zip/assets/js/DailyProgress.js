// The information of the daily progress
//--------------------------------------
dailyProgressInfo = 
[
	{
		name: "Daily Steps",
		text: "4500/5000 steps",
		progress: "90%" // The name of the file to be displayed
	},
	{
		name: "Meditation",
		text: "15/20 mins",
		progress: "75%"
	},
	{
		name: "Reward",
		text: "9/10 pages",
		progress: "90%"
	}
];
//--------------------------------------

// Create the navigation bar
(() => {
	let section = document.querySelector("#progress section");


	// Add all the wanted elements
	for(i = 0; i < dailyProgressInfo.length; i++)
	{
		section.innerHTML +=
			CreateProgressElement(dailyProgressInfo[i].name
							, dailyProgressInfo[i].text
							, dailyProgressInfo[i].progress)
		;
	}
})()

function CreateProgressElement(name, text, progress)
{
	return `<!-- The progress of the daily tasks -->
			<div class="task-progress-container">
				<label>
					${name}
				</label>
				<!-- A progress bar for a task -->
				<div class="progress-bar">
					<!-- The cover of the progress bar -->
					<div class="progress-cover">
						<!-- The filling element -->
						<div class="progress-fill" style="width: ${progress};">
							<p>${text}</p>
						</div>
					</div>
				</div>
			</div>`;
}