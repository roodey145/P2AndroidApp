// The information of the navigation bar
//--------------------------------------
navigationBarIconsPath = "../img/NavigationBar/"
navigationBarInfo = 
[
	{
		name: "Home",
		icon: "homeIcon.png",
		link: "home.html" // The name of the file to be displayed
	},
	{
		name: "Tasks",
		icon: "tasksIcon.png",
		link: "tasks.html"
	},
	{
		name: "Reward",
		icon: "rewardIcon.png",
		link: "reward.html"
	},
	{
		name: "Social",
		icon: "socialIcon.png",
		link: "social.html"
	},
	{
		name: "Settings",
		icon: "SettingIcon.png",
		link: "settings.html"
	}
];
//-------------------------------------


// Create the navigation bar
(() => {
	let nav = document.querySelector("nav");


	// Add all the wanted elements
	for(i = 0; i < navigationBarInfo.length; i++)
	{
		nav.innerHTML +=
			CreateNavElement(navigationBarInfo[i].name
							, navigationBarInfo[i].icon, i)
		;
	}
})()

function CreateNavElement(name, icon, index)
{
	return '<div class="icon-view '
			+(index == 0? "icon-view-infocus" : "") // Focus on the class
			+'" onclick="NavigateTo(\''+index+'\')">'
			+'<img id="'+name+'Icon" src="../img/NavigationBar/'+icon+'">'
			+'<label for="'+name+'Icon">'+name+'</label>'
			+'</div>';
}

function NavigateTo(info)
{
	
}