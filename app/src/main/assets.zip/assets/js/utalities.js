function CreateBlurBackground(){
	return `<!-- TODO: the top and left attr should be
			     modified using js to fit the parent position -->
			<div class="blur-background">
				<!-- The src attr should be added 
					 automaticly -->
				<img src="../img/Backgrounds/bridge.png">
				<!-- A semi-transparent element that
				     adds color tone to the 
				     background image -->
				<div class="blur-background-front-filter"></div>
			</div>`;
}